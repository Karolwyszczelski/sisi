import products from '@/data/products.json';

export function getProducts() {
  return products;
}
