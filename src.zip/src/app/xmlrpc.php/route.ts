export { GET, HEAD, POST } from "../wp-content/route";
