import { createBrowserSupabaseClient } from '@supabase/auth-helpers-nextjs';

export const supabaseBrowser = createBrowserSupabaseClient();
